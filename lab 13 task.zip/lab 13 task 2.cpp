#include<iostream>
using namespace std;

class node {
    public:
        int value;
        string name;
        double salary;
        node *left;
        node *right;

        node(int value, string name, double salary) {
            this->value = value;
            this->name = name;
            this->salary = salary;
            this->left = NULL;
            this->right = NULL;
        }

        node* insert(node* temp, int value, string name, double salary) {
            if (temp == NULL)
                return new node(value, name, salary);

            if ((temp->value) == value)
                return temp;

            if ((temp->value) < value)
                temp->right = insert(temp->right, value, name, salary);
            else
                temp->left = insert(temp->left, value, name, salary);

            return temp;
        }

        node* search(node* temp, int value) {
            if (temp == NULL || temp->value == value)
                return temp;
            if (temp->value < value)
                return search(temp->right, value);
            return search(temp->left, value);
        }

        node* getSuccessor(node* curr) {
            curr = curr->right;
            while (curr != NULL && curr->left != NULL)
                curr = curr->left;
            return curr;
        }

        node* delNode(node* root, int x) {
            if (root == NULL)
                return root;

            if (root->value > x)
                root->left = delNode(root->left, x);
            else if (root->value < x)
                root->right = delNode(root->right, x);
            else {
                if (root->left == NULL) {
                    node* temp = root->right;
                    delete root;
                    return temp;
                }

                if (root->right == NULL) {
                    node* temp = root->left;
                    delete root;
                    return temp;
                }

                node* succ = getSuccessor(root);
                root->value = succ->value;
                root->name = succ->name;
                root->salary = succ->salary;
                root->right = delNode(root->right, succ->value);
            }
            return root;
        }

        void inorder(node* root) {
            if (root != NULL) {
                inorder(root->left);
                cout << root->value << " " << root->name << " " << root->salary << endl;
                inorder(root->right);
            }
        }

        void postorder(node* temp) {
            if (temp != NULL) {
                postorder(temp->left);
                postorder(temp->right);
                cout << temp->value << " " << temp->name << " " << temp->salary << endl;
            }
        }

        void preorder(node* temp) {
            if (temp != NULL) {
                cout << temp->value << " " << temp->name << " " << temp->salary << endl;
                preorder(temp->left);
                preorder(temp->right);
            }
        }
};

int main() {
    node* root = NULL;
    root = root->insert(root, 1, "Jeon", 470000);
    root = root->insert(root, 7, "Park", 790000);
    root = root->insert(root, 6, "KIM", 69000);
    root = root->insert(root, 3, "David", 890000);

    int data;
    cout << "Enter the id that you want to search: " << endl;
    cin >> data;
    if (root->search(root, data) != NULL)
        cout << "Found!" << endl;
    else
        cout << "Not Found!" << endl;

    cout << "INORDER: " << endl;
    root->inorder(root);
    cout << endl;

    cout << "POSTORDER: " << endl;
    root->postorder(root);
    cout << endl;

    cout << "PREORDER: " << endl;
    root->preorder(root);
    cout << endl;

    int ddata;
    cout << "Enter the id that you want to delete: " << endl;
    cin >> ddata;
    root = root->delNode(root, ddata);
    cout << "INORDER after deletion: " << endl;
    root->inorder(root);
    cout << endl;

    return 0;
}

