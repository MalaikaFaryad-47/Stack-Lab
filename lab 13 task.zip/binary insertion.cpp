#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
};

Node* node(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

Node* insertNode(Node* root, int data) {
    if (root == NULL) {
        return node(data);
    }
    if (data < root->data) {
        root->left = insertNode(root->left, data);
    } else {
        root->right = insertNode(root->right, data);
    }
    return root;
}

Node* findMin(Node* root) {
    while (root->left != NULL) root = root->left;
    return root;
}

Node* deleteNode(Node* root, int data) {
    if (root == NULL) return root;
    
    if (data < root->data) {
        root->left = deleteNode(root->left, data);
    } else if (data > root->data) {
        root->right = deleteNode(root->right, data);
    } else {
        if (root->left == NULL) {
            Node* temp = root->right;
            delete root;
            return temp;
        } else if (root->right == NULL) {
            Node* temp = root->left;
            delete root;
            return temp;
        }
        
        Node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

void traversePreOrder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        traversePreOrder(root->left);
        traversePreOrder(root->right);
    }
}

void traverseInOrder(Node* root) {
    if (root != NULL) {
        traverseInOrder(root->left);
        cout << root->data << " ";
        traverseInOrder(root->right);
    }
}

void traversePostOrder(Node* root) {
    if (root != NULL) {
        traversePostOrder(root->left);
        traversePostOrder(root->right);
        cout << root->data << " ";
    }
}

void display(Node* root) {
    cout << "In-order traversal: ";
    traverseInOrder(root);
    cout << endl;

    cout << "Pre-order traversal: ";
    traversePreOrder(root);
    cout << endl;

    cout << "Post-order traversal: ";
    traversePostOrder(root);
    cout << endl;
}

int main() {
    Node* root = NULL;
    
    root = insertNode(root, 4);
    root = insertNode(root, 7);
    root = insertNode(root, 6);
    root = insertNode(root, 9);
    root = insertNode(root, 3);
    root = insertNode(root, 9);
    root = insertNode(root, 10);

    cout << "Display the tree:" << endl;
    display(root);

    root = deleteNode(root, 4);
    cout << "After deleting 4:" << endl;
    display(root);

    return 0;
}


