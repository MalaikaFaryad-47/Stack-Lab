#include <iostream>

using namespace std;

struct node {
    int data;
    struct node *left;
    struct node *right;
};

struct node* newNode(int data) {
    struct node *node = new struct node;
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

void traverseInOrder(struct node* root) {
    if (root == NULL)
        return;
    traverseInOrder(root->left);     
    cout << root->data << " ";         
    traverseInOrder(root->right);     
}

int main() {
    struct node *root = newNode(12);  

    
    root->left = newNode(7);
    root->right = newNode(9);
    root->left->left = newNode(10);
    root->left->right = newNode(22);
    root->right->left = newNode(24);
    root->right->right = newNode(30);
    root->right->right->left = newNode(18);  
    root->right->right->left->left = newNode(3); 
    root->right->right->left->right = newNode(14);  
    root->right->right->left->right->right = newNode(20);  

    
    cout << "In-order traversal: ";
    traverseInOrder(root);

    return 0;
}


